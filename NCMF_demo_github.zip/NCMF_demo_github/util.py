import numpy as np
from sklearn.ensemble import RandomForestClassifier

class ZScoreScaler:
    def fit(self, X):
        self.mean_ = X.mean(axis=0)
        self.std_ = X.std(axis=0)
        self.std_[self.std_ < 1e-8] = 1.0  # 防止除零
        return self
    def transform(self, X):
        return (X - self.mean_) / self.std_
    def fit_transform(self, X):
        return self.fit(X).transform(X)


def _fit_upper_bound_rf(X_old, y_old, X_new, y_new, rf_kwargs=None):
    """
    上界 RandomForest：用旧类 exemplars + 本轮新数据从零训练。
    返回 (rf_model or None, n_classes_used)
    """
    rf_kwargs = rf_kwargs or dict(
        n_estimators=300,
        max_depth=None,
        n_jobs=-1,
        class_weight="balanced_subsample",
        random_state=0,
    )
    # 拼接训练集
    X_list, y_list = [], []
    if X_old is not None and getattr(X_old, "size", 0):
        X_list.append(X_old); y_list.append(y_old)
    if X_new is not None and getattr(X_new, "size", 0):
        X_list.append(X_new); y_list.append(y_new)
    if not X_list:
        return None, 0

    Xub = np.vstack(X_list)
    yub = np.concatenate(y_list)

    ncls = len(np.unique(yub))
    if ncls < 2:
        # 少于2个类无法训练 RF
        return None, ncls

    rf = RandomForestClassifier(**rf_kwargs)
    rf.fit(Xub, yub)
    return rf, ncls


# ====== utils for memory reporting ======
def _sizeof_array(arr):
    return 0 if arr is None else getattr(arr, "nbytes", 0)

def _fmt_bytes(nbytes: int) -> str:
    units = ["B", "KB", "MB", "GB", "TB"]
    s = float(nbytes); u = 0
    while s >= 1024.0 and u < len(units)-1:
        s /= 1024.0; u += 1
    return f"{s:.2f} {units[u]}"

def _tree_memory_breakdown(tree) -> dict:
    """
    返回一个字典，细分 NCMTree 的各部分内存占用（以字节计）。
    仅统计 numpy 数组；Python 字典/对象元数据（例如 class_counts 的 Counter）不计入，
    因为它们不易精确统计且通常相对较小。
    """
    mem = {
        "data_X_ref": _sizeof_array(tree._X_ref),
        "data_y_ref": _sizeof_array(tree._y_ref),
        "nodes_centroids": 0,
        "nodes_centroid_labels": 0,
        "nodes_e_lr": 0,
        "leaves_indices": 0,
    }
    # 遍历所有节点
    q = deque([tree.root])
    while q:
        u = q.popleft()
        if u is None:
            continue
        if u.is_leaf:
            mem["leaves_indices"] += _sizeof_array(u.leaf_indices)
        else:
            mem["nodes_centroids"]       += _sizeof_array(u.centroids)
            mem["nodes_centroid_labels"] += _sizeof_array(u.centroid_labels)
            mem["nodes_e_lr"]            += _sizeof_array(u.e_lr)
            q.append(u.left); q.append(u.right)
    mem["total"] = sum(mem.values())
    return mem

def _forest_memory_breakdown(forest) -> dict:
    """
    汇总 NCMForest 的内存占用（逐树求和）。
    假设每棵树各自维护一份 _X_ref/_y_ref（你的实现确实如此）。
    """
    agg = {
        "data_X_ref": 0,
        "data_y_ref": 0,
        "nodes_centroids": 0,
        "nodes_centroid_labels": 0,
        "nodes_e_lr": 0,
        "leaves_indices": 0,
        "total": 0,
    }
    for t in forest.trees:
        b = _tree_memory_breakdown(t)
        for k in agg.keys():
            agg[k] += b[k]
    return agg

def print_tree_memory(tree, title="NCMTree memory"):
    b = _tree_memory_breakdown(tree)
    print(f"\n[{title}]")
    for k, v in b.items():
        print(f"  {k:20s}: {_fmt_bytes(v)}")

def print_forest_memory(forest, title="NCMForest memory"):
    b = _forest_memory_breakdown(forest)
    print(f"\n[{title}]  (n_estimators={len(forest.trees)})")
    for k, v in b.items():
        print(f"  {k:20s}: {_fmt_bytes(v)}")