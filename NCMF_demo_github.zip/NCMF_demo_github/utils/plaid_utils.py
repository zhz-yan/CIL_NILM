import numpy as np
from sklearn.metrics import accuracy_score, f1_score, classification_report
from typing import Tuple, List, Dict
from NCMF.ncmf_2 import NCMTreeNode, NCMTree, NCMForest
# ========== 可选：DataFrame 适配器 ==========
def df_to_arrays(df, feature_cols: List[str], house_col: str = "house", label_col: str = "label"):
    X = df[feature_cols].to_numpy(dtype=float)
    h = df[house_col].to_numpy()
    y = df[label_col].to_numpy(dtype=int)
    return X, y, h

# ========== 工具：按 house 划分一系列任务并在每个任务内做分层划分 ==========
def make_tasks_by_house(
    X: np.ndarray, y: np.ndarray, h: np.ndarray,
    train_ratio: float = 0.7, seed: int = 0
) -> List[Tuple[np.ndarray, np.ndarray, np.ndarray, np.ndarray]]:
    """
    返回一个列表，每个元素是 (Xtr_task, ytr_task, Xte_task, yte_task)
    每个 task 对应一个 house；task 内做按类分层的 train/test 划分。
    """
    rng = np.random.default_rng(seed)
    tasks = []
    for house in np.unique(h):
        mask = (h == house)
        X_h, y_h = X[mask], y[mask]

        # 按类分层划分
        Xtr_list, ytr_list, Xte_list, yte_list = [], [], [], []
        for cls in np.unique(y_h):
            idx = np.where(y_h == cls)[0]
            if len(idx) == 0:
                continue
            rng.shuffle(idx)
            n_tr = max(1, int(len(idx) * train_ratio))
            tr_idx, te_idx = idx[:n_tr], idx[n_tr:]
            Xtr_list.append(X_h[tr_idx]); ytr_list.append(y_h[tr_idx])
            if len(te_idx):
                Xte_list.append(X_h[te_idx]); yte_list.append(y_h[te_idx])

        if not Xtr_list:  # 该 house 没有效数据
            tasks.append((np.empty((0, X.shape[1])), np.array([], int),
                          np.empty((0, X.shape[1])), np.array([], int)))
            continue

        Xtr_task = np.vstack(Xtr_list); ytr_task = np.concatenate(ytr_list)
        if Xte_list:
            Xte_task = np.vstack(Xte_list); yte_task = np.concatenate(yte_list)
        else:
            Xte_task = np.empty((0, X.shape[1])); yte_task = np.array([], int)

        tasks.append((Xtr_task, ytr_task, Xte_task, yte_task))
    return tasks

# ========== 主流程：增量学习测试 ==========
def incremental_test_by_house(
    X: np.ndarray, y: np.ndarray, h: np.ndarray,
    init_tasks: int = 1,
    mode: str = "RTST", pi: float = 0.25, mu: int = 5, igt_min: int = 12,
    train_ratio: float = 0.7, random_state: int = 42, seed: int = 0
):
    # 1) 生成任务序列（每个 house 一个任务）
    tasks = make_tasks_by_house(X, y, h, train_ratio=train_ratio, seed=seed)
    if len(tasks) == 0:
        raise ValueError("没有任务可执行。")

    # 2) 初始任务（可由多个 house 组成，默认1个）
    Xtr0 = np.vstack([tasks[i][0] for i in range(min(init_tasks, len(tasks))) if tasks[i][0].size])
    ytr0 = np.concatenate([tasks[i][1] for i in range(min(init_tasks, len(tasks))) if tasks[i][1].size])

    Xte_seen = np.vstack([tasks[i][2] for i in range(min(init_tasks, len(tasks))) if tasks[i][2].size]) \
               if any(tasks[i][2].size for i in range(min(init_tasks, len(tasks)))) else np.empty((0, X.shape[1]))
    yte_seen = np.concatenate([tasks[i][3] for i in range(min(init_tasks, len(tasks))) if tasks[i][3].size]) \
               if any(tasks[i][3].size for i in range(min(init_tasks, len(tasks)))) else np.array([], int)

    if Xtr0.size == 0:
        raise ValueError("初始任务没有训练数据。请调大 init_tasks 或检查数据。")

    # 3) 训练初始模型（NCMForest 与你之前一致）
    clf = NCMForest(
        n_estimators=10,
        max_depth=11,
        min_samples_leaf=2,
        max_class_subset=8,
        n_candidate_splits=64,
        bootstrap=True,
        random_state=random_state
    )
    clf.fit(Xtr0, ytr0)

    if Xte_seen.size:
        ypred0 = clf.predict(Xte_seen)
        print(f"[Init] ACC={accuracy_score(yte_seen, ypred0):.4f} "
              f"macroF1={f1_score(yte_seen, ypred0, average='macro'):.4f}")
    else:
        print("[Init] 训练完成（无初始测试集）。")

    # 4) 逐 house 增量
    round_id = 1
    for t in range(init_tasks, len(tasks)):
        Xtr_t, ytr_t, Xte_t, yte_t = tasks[t]
        if not Xtr_t.size:
            print(f"[Round {round_id:02d}] Task-{t} 无训练数据，跳过。")
            round_id += 1
            continue

        # 本任务的所有新类一次性喂入
        clf.partial_fit(Xtr_t, ytr_t, mode=mode, pi=pi, mu=mu, igt_min_new_per_leaf=igt_min)

        # 累积测试集（评估“所有已见到的类”）
        if Xte_t.size:
            if Xte_seen.size:
                Xte_seen = np.vstack([Xte_seen, Xte_t])
                yte_seen = np.concatenate([yte_seen, yte_t])
            else:
                Xte_seen, yte_seen = Xte_t, yte_t

        if Xte_seen.size:
            ypred = clf.predict(Xte_seen)
            acc = accuracy_score(yte_seen, ypred)
            mf1 = f1_score(yte_seen, ypred, average='macro')
            print(f"[Round {round_id:02d}] +{len(np.unique(ytr_t))} classes | "
                  f"ACC={acc:.4f}  macroF1={mf1:.4f}")
        else:
            print(f"[Round {round_id:02d}] 完成训练（当前无测试集）。")
        round_id += 1

    # 5) 最终报告
    if Xte_seen.size:
        ypred = clf.predict(Xte_seen)
        print("\n[Final report]")
        print(classification_report(yte_seen, ypred, digits=4))
    return clf