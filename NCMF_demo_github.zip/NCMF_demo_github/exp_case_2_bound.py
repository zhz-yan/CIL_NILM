import os, json, time
import numpy as np
from collections import defaultdict
from typing import Dict, List, Any, Tuple
from sklearn.metrics import accuracy_score, f1_score, classification_report

from NCMF.ncmf_2 import NCMForest
from NCMF.exemplar_memory import ExemplarMemory
from sklearn.ensemble import RandomForestClassifier


def run_repeated_experiments(
    X, y,
    dataset_name="plaid",
    model_name="ncmf",
    results_root="results",
    repeats=5,
    init_classes=5,
    step_each_round=2,
    train_ratio=0.7,
    mode="RTST",
    pi=0.8,
    use_replay=True,
    mem_budget=500,
    mem_per_class=5
):
    """
    运行多次实验，每次都调用 run_cil_single_dataset 并保存 json。
    """
    for exp_idx in range(repeats):
        print(f"\n===== Running {model_name.upper()} on {dataset_name} | exp {exp_idx} =====")
        run_cil_single_dataset(
            X, y,
            dataset_name=dataset_name,
            model_name=model_name,
            results_root=results_root,
            exp_idx=exp_idx,
            init_classes=init_classes,
            step_each_round=step_each_round,
            train_ratio=train_ratio,
            mode=mode,
            pi=pi,
            use_replay=use_replay,
            mem_budget=mem_budget,
            mem_per_class=mem_per_class,
            random_state=exp_idx  # 每次随机种子不同
        )


# ---------- JSON 工具 ----------
class NumpyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, (np.integer,)):
            return int(obj)
        if isinstance(obj, (np.floating,)):
            return float(obj)
        if isinstance(obj, (np.ndarray,)):
            return obj.tolist()
        return super().default(obj)


def save_json(obj, path):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        json.dump(obj, f, indent=2, ensure_ascii=False, cls=NumpyEncoder)


# ---------- 小工具（你原有的保持不变） ----------
def group_by_type(X: np.ndarray, y_type: np.ndarray) -> Dict[Any, List[np.ndarray]]:
    X = np.asarray(X); y = np.asarray(y_type)
    out = defaultdict(list)
    for xi, ti in zip(X, y):
        out[ti].append(np.asarray(xi))
    return dict(out)


def split_per_class(arr_list: List[np.ndarray], train_ratio: float, rng) -> Tuple[np.ndarray, np.ndarray]:
    idx = np.arange(len(arr_list)); rng.shuffle(idx)
    n_tr = max(1, int(len(idx) * train_ratio))
    tr, te = idx[:n_tr], idx[n_tr:]
    Xtr = np.vstack([arr_list[i] for i in tr]) if len(tr) else np.empty((0, arr_list[0].shape[0]))
    Xte = np.vstack([arr_list[i] for i in te]) if len(te) else np.empty((0, arr_list[0].shape[0]))
    return Xtr, Xte


def dict_to_Xy_single(task: Dict[Any, List[np.ndarray]], label2id: Dict[Any, int],
                      next_id: int, train_ratio: float, rng):
    Xtr_list, ytr_list, Xte_list, yte_list = [], [], [], []
    for t, samples in task.items():
        if len(samples) == 0: continue
        if t not in label2id:
            label2id[t] = next_id; next_id += 1
        cid = label2id[t]
        Xtr_c, Xte_c = split_per_class(samples, train_ratio, rng)
        if Xtr_c.size:
            Xtr_list.append(Xtr_c); ytr_list.append(np.full(len(Xtr_c), cid, int))
        if Xte_c.size:
            Xte_list.append(Xte_c); yte_list.append(np.full(len(Xte_c), cid, int))
    if not Xtr_list:
        return (np.empty((0,0)), np.array([], int), np.empty((0,0)), np.array([], int), next_id)
    Xtr = np.vstack(Xtr_list); ytr = np.concatenate(ytr_list)
    Xte = np.vstack(Xte_list) if Xte_list else np.empty((0, Xtr.shape[1]))
    yte = np.concatenate(yte_list) if yte_list else np.array([], int)
    return Xtr, ytr, Xte, yte, next_id


# ---------- 评估子集指标 ----------
def subset_metrics(y_true, y_pred):
    if y_true.size == 0:
        return dict(support=0, f1_macro=float("nan"), accuracy=float("nan"))
    return dict(
        support=int(y_true.size),
        f1_macro=float(f1_score(y_true, y_pred, average="macro")),
        accuracy=float(accuracy_score(y_true, y_pred))
    )


# ---------- CIL 主流程 + JSON 记录 ----------
def run_cil_single_dataset(
    X, y_type,
    dataset_name="plaid",
    model_name="ncmf",
    results_root="results",
    exp_idx=0,
    init_classes=3, step_each_round=2, train_ratio=0.7,
    random_state=1993, mode="RTST", pi=0.6, mu=5, igt_min=12,
    use_replay=True, mem_budget=300, mem_per_class=5, replay_ratio=1.0,
    use_zscore=True,
    metric="euclidean", use_diag=True, ridge=1e-2, update_metric_on_partial=False,
    bootstrap=False
):
    rng = np.random.default_rng(random_state)
    t0_wall = time.perf_counter()

    # ---- 准备 JSON 外层 config ----
    config_block = dict(
        config="(ncmf_inline)",
        repeats=1,
        model_name=model_name,
        prefix=model_name.upper(),
        memory_size=mem_budget,
        dataset=dataset_name,
        seed=random_state,
        shuffle=True,
        device=["cpu"],             # 如需可填 GPU 名称
        convnet_type="(none)",
        init_cls=init_classes,
        increment=step_each_round,
        num_workers=0,
        init_batch_size=0, IL_batch_size=0,
        inplace_repeat=1,
        exp_idx=exp_idx,
        buffer_size=mem_budget,
        gamma=None,
        init_weight_decay=None,
        scheduler={}
    )

    # ---- CIL 数据准备 ----
    type_dict = group_by_type(X, y_type)
    all_types = list(type_dict.keys());
    rng.shuffle(all_types)
    init_types = all_types[:init_classes]
    rest_types = all_types[init_classes:]
    label2id: Dict[Any, int] = {};
    next_id = 0

    init_task = {t: type_dict[t] for t in init_types}
    Xtr0, ytr0, Xte0, yte0, next_id = dict_to_Xy_single(init_task, label2id, next_id, train_ratio, rng)

    # z-score：固定用初始训练集的统计量（保持一致性）
    if use_zscore:
        mean = Xtr0.mean(axis=0, keepdims=True);
        std = Xtr0.std(axis=0, keepdims=True) + 1e-8
        trf = lambda X_: (X_ - mean) / std
        Xtr0 = trf(Xtr0);
        Xte0 = trf(Xte0)
    else:
        trf = lambda X_: X_

    # ----------- 改为随机森林 -----------
    rf = RandomForestClassifier(
        n_estimators=300,  # 可按需要调
        max_depth=None,
        min_samples_leaf=1,
        n_jobs=-1,
        random_state=random_state
    )

    # 累积训练集（每个 task 后都用它来整模重训）
    Xtrain_cum = Xtr0.copy()
    ytrain_cum = ytr0.copy()

    # 首次训练
    if Xtrain_cum.size:
        rf.fit(Xtrain_cum, ytrain_cum)

    # 记录容器
    tasks_log = []
    top1_curve = []

    # 初始测试集（仅包含首批类别）
    Xte_seen, yte_seen = Xte0, yte0

    # 初始评估
    if Xte_seen.size:
        ypred0 = rf.predict(Xte_seen)
        acc0 = float(accuracy_score(yte_seen, ypred0))
        f10 = float(f1_score(yte_seen, ypred0, average="macro"))
        top1_curve.append(round(acc0 * 100, 2))

        percls = classification_report(yte_seen, ypred0, output_dict=True, zero_division=0)
        task_record = dict(
            task_id=0,
            known_classes=0,
            total_classes=int(len(np.unique(ytr0))),
            time_sec=0.0,
            metrics=dict(
                accuracy=acc0,
                precision_macro=float(np.mean([v["precision"] for k, v in percls.items() if k.isdigit()])),
                recall_macro=float(np.mean([v["recall"] for k, v in percls.items() if k.isdigit()])),
                f1_macro=f10
            ),
            per_class={k: v for k, v in percls.items() if k.isdigit()},
            groups=dict(
                old=dict(support=0, f1_macro=float("nan"), accuracy=float("nan")),
                new=dict(support=int(yte_seen.size),
                         f1_macro=float(f1_score(yte_seen, ypred0, average="macro")),
                         accuracy=float(accuracy_score(yte_seen, ypred0)))
            ),
            # —— 保存预测（可选；若太大可去掉）——
            predictions=dict(y_true=yte_seen, y_pred=ypred0)
        )
        tasks_log.append(task_record)

    # 逐轮增量
    rounds = 0
    seen_classes_prev = set(np.unique(ytr0))
    i = 0
    while i < len(rest_types):
        add_types = rest_types[i:i + step_each_round];
        i += step_each_round;
        rounds += 1
        task = {t: type_dict[t] for t in add_types}

        Xtr_new, ytr_new, Xte_new, yte_new, next_id = dict_to_Xy_single(task, label2id, next_id, train_ratio, rng)
        if Xtr_new.size == 0:
            continue

        Xtr_new = trf(Xtr_new)
        if Xte_new.size: Xte_new = trf(Xte_new)

        # —— 累积训练集并整模重训（核心改动）——
        t_start = time.perf_counter()
        Xtrain_cum = np.vstack([Xtrain_cum, Xtr_new]) if Xtrain_cum.size else Xtr_new
        ytrain_cum = np.concatenate([ytrain_cum, ytr_new]) if ytrain_cum.size else ytr_new

        rf = RandomForestClassifier(
            n_estimators=300,
            max_depth=None,
            min_samples_leaf=1,
            n_jobs=-1,
            random_state=random_state
        )
        rf.fit(Xtrain_cum, ytrain_cum)
        t_dur = float(time.perf_counter() - t_start)

        # —— 扩展累计测试集（历次任务的测试合集）——
        if Xte_new.size:
            Xte_seen = np.vstack([Xte_seen, Xte_new]) if Xte_seen.size else Xte_new
            yte_seen = np.concatenate([yte_seen, yte_new]) if yte_seen.size else yte_new

        # 评估
        ypred = rf.predict(Xte_seen)
        acc = float(accuracy_score(yte_seen, ypred))
        f1m = float(f1_score(yte_seen, ypred, average="macro"))
        top1_curve.append(round(acc * 100, 2))

        new_cls = set(np.unique(ytr_new))
        old_mask = np.isin(yte_seen, list(seen_classes_prev))
        new_mask = np.isin(yte_seen, list(new_cls))

        from collections import Counter
        def subset_metrics(y_true, y_pred):
            if y_true.size == 0:
                return dict(support=0, f1_macro=float("nan"), accuracy=float("nan"))
            return dict(
                support=int(y_true.size),
                f1_macro=float(f1_score(y_true, y_pred, average="macro")),
                accuracy=float(accuracy_score(y_true, y_pred))
            )

        grp_old = subset_metrics(yte_seen[old_mask], ypred[old_mask])
        grp_new = subset_metrics(yte_seen[new_mask], ypred[new_mask])

        percls = classification_report(yte_seen, ypred, output_dict=True, zero_division=0)
        task_record = dict(
            task_id=rounds,
            known_classes=len(seen_classes_prev),
            total_classes=len(seen_classes_prev.union(new_cls)),
            time_sec=t_dur,
            metrics=dict(
                accuracy=acc,
                precision_macro=float(np.mean([v["precision"] for k, v in percls.items() if k.isdigit()])),
                recall_macro=float(np.mean([v["recall"] for k, v in percls.items() if k.isdigit()])),
                f1_macro=f1m
            ),
            per_class={k: v for k, v in percls.items() if k.isdigit()},
            groups=dict(old=grp_old, new=grp_new),
            # —— 保存预测（可选；若太大可去掉）——
            predictions=dict(y_true=yte_seen, y_pred=ypred)
        )
        tasks_log.append(task_record)

        # 更新已见类别集合
        seen_classes_prev = seen_classes_prev.union(new_cls)

    # ---- 汇总 & 保存（原样保留）----
    summary = dict(
        num_tasks=len(tasks_log),
        top1_curve=[float(x) for x in top1_curve],
        avg_top1=float(np.mean(top1_curve)) if top1_curve else float("nan")
    )

    payload = dict(
        config=config_block,
        env=dict(python="", platform="", torch="", cuda_available=False, cuda_device_count=0, cuda_names=[]),
        tasks=tasks_log,
        summary=summary,
        run_wall_time_sec=float(time.perf_counter() - t0_wall),
        run_extra=dict(exp_idx=exp_idx)
    )

    out_dir = os.path.join(results_root, "case_2", "bound")
    fname = f"{model_name}_{dataset_name}_ba_{init_classes}_in_{step_each_round}_exp_{exp_idx}.json"
    save_json(payload, os.path.join(out_dir, fname))
    print(f"[OK] JSON saved -> {os.path.join(out_dir, fname)}")


dataset_name = "case_2"

X = np.load(f"data/{dataset_name}/X_case2.npy")
y = np.load(f"data/{dataset_name}/Y_case2.npy")

run_repeated_experiments(
    X, y,
    dataset_name=f"{dataset_name}",
    model_name="ncmf",
    results_root="results",
    repeats=1,        # 重复次数
    init_classes=10,
    step_each_round=3,
    train_ratio=0.7,
    pi=0.6,
    mode="RTST",
    use_replay=False,
    mem_budget=500,
    mem_per_class=20
)

