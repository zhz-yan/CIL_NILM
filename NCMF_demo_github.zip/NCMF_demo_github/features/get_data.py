from features.get_features import create_features
from sklearn.preprocessing import LabelEncoder
import numpy as np

from dataset.load_whited_data import *
from sklearn.preprocessing import MinMaxScaler, StandardScaler
from sklearn.model_selection import train_test_split
# from gao_features import gao_features

def split_open_set(data, labels, known_classes, test_size=0.2):
    # Convert known_classes to a set for faster membership testing
    known_classes_set = set(known_classes)

    # Identify known and unknown indices based on labels
    known_indices = [i for i, label in enumerate(labels) if label in known_classes_set]
    unknown_indices = [i for i, label in enumerate(labels) if label not in known_classes_set]

    # Split known data
    known_data = data[known_indices]
    known_labels = labels[known_indices]

    # Split unknown data
    unknown_data = data[unknown_indices]
    unknown_labels = labels[unknown_indices]

    # Split the known data into training and testing sets
    train_X, test_known_X, train_y, test_known_y = train_test_split(known_data, known_labels, test_size=test_size, stratify=known_labels)

    train_X, val_X, train_y, val_y = train_test_split(train_X, train_y, test_size=0.2)

    # Normalization harmonics
    scaler = MinMaxScaler()
    # scaler = StandardScaler()

    train_X = scaler.fit_transform(train_X)
    val_X = scaler.transform(val_X)
    test_known_X = scaler.transform(test_known_X)
    unknown_data = scaler.transform(unknown_data)

    data = {"train_data_1": train_X,
            "train_y": train_y,
            "val_data": val_X,
            "val_y": val_y,
            "test_data_1": test_known_X,
            "test_y": test_known_y,
            "out_data_1": unknown_data,
            "out_y": unknown_labels
    }

    return data


def get_features(dataset_name: str = 'plaid'):

    datasets = {"plaid": "D:/datasets/nilm/plaid/PLAID/",
                "whited": "D:/datasets/nilm/WHITED/",
                "cooll": "D:/datasets/nilm/COOLL/"}

    current, voltage, label, region = get_whited_feature(datasets['whited'])
    house_label = None
    eps = 1e3
    steps = 50
    delta = 50
    fs = 44.1e3

    # get features
    clf_feat = create_features(voltage, current, fs)

    np.save('../data/case_1/whited/X.npy', clf_feat)
    np.save('../data/case_1/whited/Y.npy', label)

    return clf_feat


if __name__ == '__main__':
    print("start...")
    datasets = ["cooll", "plaid", "whited"]
    features = ["gaf", "vi", "wrg",  "raw", "tradition"]
    n_epochs = 400
    batch_size = 8
    width = 60     # (32), 40, 60, 80, 100, 128
    run_id = 1

    dataset = datasets[1]
    # feature = features[2]
    feature = "sdp"
    print("Starting 5-cv experiment...")
    # for dataset in datasets:
    print("Loading {} dataset...".format(dataset))

    data = get_features(dataset_name = "whited")





