# ncm_forest_incremental.py
import numpy as np
from collections import Counter, defaultdict, deque
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.metrics import accuracy_score, f1_score

# ---------- Utils ----------
def entropy(y):
    if y.size == 0:
        return 0.0
    counts = np.bincount(y)
    probs = counts[counts > 0].astype(float) / y.size
    return -np.sum(probs * np.log2(probs))

def information_gain(y_parent, y_left, y_right):
    H_parent = entropy(y_parent)
    n = y_parent.size
    n_l = y_left.size
    n_r = y_right.size
    if n_l == 0 or n_r == 0:
        return 0.0
    return H_parent - (n_l / n) * entropy(y_left) - (n_r / n) * entropy(y_right)

def nearest_centroid_assign(X, C, M=None):
    """
    返回每个样本到最近质心的下标（按二次型距离最小）。
    参数
    ----
    X : (n, d)  样本
    C : (k, d)  质心
    M : None | (d,) | (d,d)
        - None : 欧氏距离（平方）
        - (d,) : 对角马氏（精度向量，等价于 diag(M)）
        - (d,d): 全马氏（精度矩阵 Σ^{-1}）

    距离定义：
        d^2(x,c) = (x-c)^T M (x-c)
      欧氏情形等价于 M=I。
    """
    X = np.asarray(X, dtype=float)
    C = np.asarray(C, dtype=float)
    n, d = X.shape
    if C.ndim != 2 or C.shape[1] != d:
        raise ValueError(f"C shape {C.shape} 与 X 维度 {d} 不匹配")
    if n == 0 or C.shape[0] == 0:
        return np.empty((n,), dtype=int)

    if M is None:
        # 欧氏：||x||^2 - 2 x·c + ||c||^2
        xq = (X**2).sum(1)[:, None]          # (n,1)
        cq = (C**2).sum(1)[None, :]          # (1,k)
        D  = xq - 2.0 * (X @ C.T) + cq       # (n,k)
    else:
        M = np.asarray(M, dtype=float)
        if M.ndim == 1:
            # 对角马氏：按元素加权
            XM = X * M[None, :]              # (n,d)
            CM = C * M[None, :]              # (k,d)
            xq = np.einsum('ij,ij->i', XM, X)[:, None]   # (n,1)
            cq = np.einsum('ij,ij->i', CM, C)[None, :]   # (1,k)
            D  = xq - 2.0 * (XM @ C.T) + cq
        elif M.ndim == 2 and M.shape == (d, d):
            XM = X @ M                        # (n,d)
            CM = C @ M                        # (k,d)
            xq = np.einsum('ij,ij->i', XM, X)[:, None]   # (n,1)
            cq = np.einsum('ij,ij->i', CM, C)[None, :]   # (1,k)
            D  = xq - 2.0 * (XM @ C.T) + cq
        else:
            raise ValueError(f"M 形状不合法：{M.shape}，期望 None/(d,)/(d,d)")

    return np.argmin(D, axis=1)


def _compute_pooled_precision(X, ridge=1e-3, use_diag=False):
    """
    估计全局 Σ 并返回其逆（精度矩阵 M=Σ^{-1}）。
    - ridge: Σ ← Σ + ridge·I 以保证可逆/稳定
    - use_diag=True: 只用对角近似（对白化/尺度差有用，最稳）
    """
    X = np.asarray(X, dtype=float)
    # 协方差（无偏），行是样本
    S = np.cov(X, rowvar=False)
    d = S.shape[0]
    if use_diag:
        S = np.diag(np.diag(S))
    S = S + ridge * np.eye(d)
    # 用 pinv 更稳（高维或相关性强时）
    try:
        from numpy.linalg import inv
        M = inv(S)
    except Exception:
        from numpy.linalg import pinv
        M = pinv(S)
    return M


def _nearest_centroid_argmin(X, C, M=None):
    """
    返回每个 x 到质心集合 C 的最近下标。
    - 欧氏:  M=None
    - 马氏:  d^2(x,c)=(x-c)^T M (x-c)
    向量化实现：x^T M x - 2 x^T M c + c^T M c
    """
    X = np.asarray(X, dtype=float)
    C = np.asarray(C, dtype=float)
    if M is None:
        # 欧氏距离
        # ||x-c||^2 = ||x||^2 - 2 x·c + ||c||^2
        xq = (X**2).sum(1)[:, None]
        cq = (C**2).sum(1)[None, :]
        D = xq - 2 * (X @ C.T) + cq
        return np.argmin(D, axis=1)

    XM = X @ M           # (n,d)
    CM = C @ M           # (k,d)
    xq = np.einsum('ij,ij->i', XM, X)[:, None]      # (n,1)
    cq = np.einsum('ij,ij->i', CM, C)[None, :]      # (1,k)
    D = xq - 2.0 * (XM @ C.T) + cq                  # (n,k)
    return np.argmin(D, axis=1)


def _nbytes_array(a):
    return 0 if a is None else int(getattr(a, "nbytes", 0))


def bytes_to_mb(n): return n / (1024.0**2)

def bytes_to_kb(n):
    return n / 1024.0


def estimate_tree_model_bytes(tree):
    """推理必需（不含训练缓存）的数组字节数下界"""
    total = 0
    # 马氏精度矩阵（若使用）
    total += _nbytes_array(tree.M_)  # d*d*b_float 或 0
    # BFS 遍历所有节点
    q = [tree.root]
    while q:
        n = q.pop(0)
        if n is None: continue
        if n.is_leaf:
            # 叶子里：只需要 class_counts（下界用稠密/稀疏都可以做估）
            # 这里用“类别ID+计数”的下界近似：每项两个 int
            if n.class_counts is not None:
                total += len(n.class_counts) * (np.dtype(np.int64).itemsize * 2)
        else:
            # 内节点：centroids + e_lr + centroid_labels
            total += _nbytes_array(n.centroids)        # (k,d) float
            total += _nbytes_array(n.e_lr)             # (k,) int
            total += _nbytes_array(n.centroid_labels)  # (k,) int
            q.append(n.left); q.append(n.right)
    return total


def estimate_tree_training_bytes(tree):
    """增量学习需要保留的训练缓存（_X_ref/_y_ref/leaf_indices）"""
    total = 0
    # 全局训练缓存
    total += _nbytes_array(tree._X_ref)  # (N,d) float
    total += _nbytes_array(tree._y_ref)  # (N,) int
    # 叶子的样本索引：总和≈N（每样本挂一次）
    q = [tree.root]
    while q:
        n = q.pop(0)
        if n is None: continue
        if n.is_leaf:
            total += _nbytes_array(n.leaf_indices)  # (n_leaf,) int
        else:
            q.append(n.left); q.append(n.right)
    return total


def report_ncmf_sizes(forest):
    model_bytes = 0
    train_bytes = 0
    for t in forest.trees:
        model_bytes += estimate_tree_model_bytes(t)
        train_bytes += estimate_tree_training_bytes(t)
    print(f"[NCMF] #trees={len(forest.trees)}")
    # print(f"  Model size (inference-needed only): {bytes_to_mb(model_bytes):.2f} MB")
    # print(f"  Memory size (incremental cache):     {bytes_to_mb(train_bytes):.2f} MB")
    # print(f"  Total (runtime footprint lower-bound): {bytes_to_mb(model_bytes+train_bytes):.2f} MB")

    print(f"  Model size (inference-needed only): {bytes_to_kb(model_bytes):.2f} KB")
    print(f"  Memory size (incremental cache):     {bytes_to_kb(train_bytes):.2f} KB")
    print(f"  Total (runtime footprint lower-bound): {bytes_to_kb(model_bytes+train_bytes):.2f} KB")

def get_ncmf_sizes(forest):
    """
    统计 NCMF 模型大小和训练态内存大小。
    返回:
      - model_bytes:  推理需要保留的内容总字节数 (所有树 estimate_tree_model_bytes 累加)
      - train_bytes:  训练/增量更新阶段需要的额外状态字节数 (estimate_tree_training_bytes 累加)
    """
    model_bytes = 0
    train_bytes = 0
    for t in forest.trees:
        model_bytes += estimate_tree_model_bytes(t)
        train_bytes += estimate_tree_training_bytes(t)

    out = dict(
        num_trees = len(forest.trees),
        model_bytes = int(model_bytes),
        model_kb = float(model_bytes / 1024.0),
        train_bytes = int(train_bytes),
        train_kb = float(train_bytes / 1024.0),
    )
    return out



# ---------- NCM Tree ----------
# ---------- Tree node ----------
class NCMTreeNode:
    __slots__ = ("is_leaf","class_counts","centroids","centroid_labels","e_lr",
                 "left","right","leaf_indices")
    def __init__(self, is_leaf=False):
        self.is_leaf = is_leaf
        self.class_counts = None
        self.centroids = None
        self.centroid_labels = None
        self.e_lr = None
        self.left = None
        self.right = None
        self.leaf_indices = None  # indices into tree._X_ref / _y_ref

# ---------- NCM Tree ----------
class NCMTree:
    def __init__(self,
                 max_depth=10,
                 min_samples_leaf=5,
                 max_class_subset=8,
                 n_candidate_splits=32,
                 random_state=None,
                 metric="euclidean",          # 新增: "euclidean" | "mahalanobis"
                 ridge=1e-3,                  # Σ 的岭化
                 use_diag=False,              # 马氏是否用对角近似
                 update_metric_on_partial=True):  # 增量时是否重算 M
        self.max_depth = max_depth
        self.min_samples_leaf = min_samples_leaf
        self.max_class_subset = max_class_subset
        self.n_candidate_splits = n_candidate_splits
        self.rng = np.random.default_rng(random_state)
        self.root = None
        self.n_classes_ = None
        self._X_ref = None
        self._y_ref = None
        self._idx_ref = None

        # ---- metric 相关 ----
        self.metric = metric.lower()
        self.ridge = ridge
        self.use_diag = use_diag
        self.update_metric_on_partial = update_metric_on_partial
        self.M_ = None   # 全局精度矩阵 (Σ^{-1})

    def _refresh_metric_if_needed(self):
        # 仅在使用马氏距离且允许增量重估时才重算
        if getattr(self, "metric", "euclidean") == "mahalanobis" and \
                getattr(self, "update_metric_on_partial", False):
            self.M_ = _compute_pooled_precision(
                self._X_ref, ridge=self.ridge, use_diag=self.use_diag
            )

    # ====== Batch training ======
    def fit(self, X, y):
        X = np.asarray(X);
        y = np.asarray(y, dtype=int)
        self.n_classes_ = int(np.max(y)) + 1
        self._X_ref, self._y_ref = X, y
        self._idx_ref = np.arange(X.shape[0], dtype=int)
        # 先长树
        self.root = self._grow_node(X, y, self._idx_ref, depth=0)
        # 再估计全局马氏（如果需要）
        if self.metric == "mahalanobis":
            self.M_ = _compute_pooled_precision(self._X_ref, ridge=self.ridge, use_diag=self.use_diag)
        else:
            self.M_ = None
        return self

    def _grow_node(self, X, y, idx, depth):
        node = NCMTreeNode()
        # stop criteria
        if (depth >= self.max_depth or
            X.shape[0] <= self.min_samples_leaf or
            np.unique(y).size == 1):
            node.is_leaf = True
            node.class_counts = Counter(y.tolist())
            node.leaf_indices = idx.copy()
            return node

        classes_here = np.unique(y)
        if classes_here.size == 1:
            node.is_leaf = True
            node.class_counts = Counter(y.tolist())
            node.leaf_indices = idx.copy()
            return node

        # sample class subset K^n
        if classes_here.size > self.max_class_subset:
            subset = self.rng.choice(classes_here, size=self.max_class_subset, replace=False)
        else:
            subset = classes_here

        # centroids
        C, L = [], []
        for c in subset:
            Xc = X[y == c]
            C.append(Xc.mean(axis=0)); L.append(c)
        C = np.stack(C, axis=0); L = np.array(L)

        # assign nearest centroid once
        nn_idx = nearest_centroid_assign(X, C)
        byc = defaultdict(list)
        for i, ci in enumerate(nn_idx): byc[ci].append(i)
        for k in byc.keys(): byc[k] = np.array(byc[k], dtype=int)

        # try random e_k and select by IG
        best_gain, best_e, best_L, best_R = -1.0, None, None, None
        for _ in range(self.n_candidate_splits):
            e = self.rng.integers(0, 2, size=C.shape[0], dtype=int)
            Ls, Rs = [], []
            for ci, ee in enumerate(e):
                loc = byc.get(ci, None)
                if loc is None or loc.size == 0: continue
                (Ls if ee == 0 else Rs).append(loc)
            if not Ls or not Rs: continue
            L_loc = np.concatenate(Ls); R_loc = np.concatenate(Rs)
            if L_loc.size < self.min_samples_leaf or R_loc.size < self.min_samples_leaf: continue
            gain = information_gain(y, y[L_loc], y[R_loc])
            if gain > best_gain:
                best_gain, best_e, best_L, best_R = gain, e, L_loc, R_loc

        if best_gain <= 0 or best_L is None:
            node.is_leaf = True
            node.class_counts = Counter(y.tolist())
            node.leaf_indices = idx.copy()
            return node

        node.is_leaf = False
        node.centroids = C
        node.centroid_labels = L
        node.e_lr = best_e.astype(int)

        node.left  = self._grow_node(X[best_L], y[best_L], idx[best_L], depth+1)
        node.right = self._grow_node(X[best_R], y[best_R], idx[best_R], depth+1)
        return node

    # ====== Inference ======
    def _route_single(self, node, x):
        x = np.asarray(x, dtype=float)
        while not node.is_leaf:
            C = node.centroids
            if self.M_ is None:
                # 欧氏
                ci = np.argmin(np.sum((C - x) ** 2, axis=1))
            else:
                # 马氏：逐类算 (c-x)^T M (c-x)
                # 等价于：x^T M x - 2 x^T M c + c^T M c
                XMx = x @ self.M_ @ x
                CM = C @ self.M_
                d = XMx - 2.0 * (x @ CM.T) + np.einsum('ij,ij->i', CM, C)
                ci = int(np.argmin(d))
            node = node.left if node.e_lr[ci] == 0 else node.right
        return node

    def predict_proba(self, X):
        X = np.asarray(X)
        P = np.zeros((len(X), self.n_classes_), float)
        for i, x in enumerate(X):
            leaf = self._route_single(self.root, x)
            counts = np.zeros(self.n_classes_, float)
            for k, v in leaf.class_counts.items():
                k = int(k)
                if k >= counts.shape[0]:
                    # 防御：若增量后类别数变了
                    counts = np.pad(counts, (0, k+1-counts.shape[0]))
                counts[k] = v
            s = counts.sum()
            P[i] = counts / s if s > 0 else 1.0 / max(1, self.n_classes_)
        return P

    def predict(self, X):
        return np.argmax(self.predict_proba(X), axis=1)

    # ====== helpers ======
    def _collect_nodes_bfs(self):
        out, q = [], deque([self.root])
        while q:
            u = q.popleft(); out.append(u)
            if u and not u.is_leaf:
                q.append(u.left); q.append(u.right)
        return out

    def _subtree_size(self, n):
        s, q = 0, deque([n])
        while q:
            u = q.popleft()
            if u is None: continue
            s += 1
            if not u.is_leaf:
                q.append(u.left); q.append(u.right)
        return s

    def _sample_update_nodes(self, pi=0.2):
        cand = [n for n in self._collect_nodes_bfs() if not n.is_leaf]
        if not cand: return []
        sizes = np.array([self._subtree_size(n) for n in cand], float)
        w = 1.0 / (sizes + 1.0); p = w / w.sum()
        k = max(1, int(np.ceil(pi * len(cand))))
        sel = self.rng.choice(len(cand), size=k, replace=False, p=p)
        # return in BFS order
        order = {id(n): i for i, n in enumerate(self._collect_nodes_bfs())}
        picked = [cand[i] for i in sel]
        picked.sort(key=lambda n: order[id(n)])
        return picked

    def _recompute_leaf_stats(self, leaf):
        ys = self._y_ref[leaf.leaf_indices]
        leaf.class_counts = Counter(ys.tolist())

    def _route_indices_through_subtree(self, node, idxs):
        """将一组样本索引按 node 的当前分裂函数在其子树内重新路由。"""
        if idxs.size == 0:
            return

        # ✅ 关键修复：若 node 本身是叶子，直接落到这个叶子
        if node.is_leaf:
            node.leaf_indices = idxs
            self._recompute_leaf_stats(node)
            return

        # 下面才是对“内部节点”的路由逻辑
        Xs = self._X_ref[idxs]
        nn = nearest_centroid_assign(Xs, node.centroids, M=self.M_)

        left_mask = np.zeros(len(idxs), dtype=bool)
        for ci, ee in enumerate(node.e_lr):
            if ee == 0:
                left_mask |= (nn == ci)
        right_mask = ~left_mask

        # 递归地把样本分发到左右子树
        if node.left.is_leaf:
            node.left.leaf_indices = idxs[left_mask]
            self._recompute_leaf_stats(node.left)
        else:
            self._route_indices_through_subtree(node.left, idxs[left_mask])

        if node.right.is_leaf:
            node.right.leaf_indices = idxs[right_mask]
            self._recompute_leaf_stats(node.right)
        else:
            self._route_indices_through_subtree(node.right, idxs[right_mask])

    def _prune_min_leaf(self, node, mu):
        if node is None or node.is_leaf: return node
        node.left  = self._prune_min_leaf(node.left, mu)
        node.right = self._prune_min_leaf(node.right, mu)
        if node.left is None or node.right is None: return node
        if node.left.is_leaf and node.right.is_leaf:
            nL = 0 if node.left.leaf_indices  is None else len(node.left.leaf_indices)
            nR = 0 if node.right.leaf_indices is None else len(node.right.leaf_indices)
            if nL < mu or nR < mu:
                merged = NCMTreeNode(is_leaf=True)
                idsL = node.left.leaf_indices  if node.left.leaf_indices  is not None else np.array([], int)
                idsR = node.right.leaf_indices if node.right.leaf_indices is not None else np.array([], int)
                merged.leaf_indices = np.concatenate([idsL, idsR]) if idsL.size + idsR.size > 0 else np.array([], int)
                self._recompute_leaf_stats(merged)
                return merged
        return node

    def _depth_of(self, target):
        q = deque([(self.root, 0)])
        while q:
            u, d = q.popleft()
            if u is target: return d
            if u and not u.is_leaf:
                q.append((u.left, d+1)); q.append((u.right, d+1))
        return 0

    def _replace_node(self, old_node, new_node):
        if self.root is old_node:
            self.root = new_node; return
        q = deque([self.root])
        while q:
            u = q.popleft()
            if u is None or u.is_leaf: continue
            if u.left is old_node:
                u.left = new_node; return
            if u.right is old_node:
                u.right = new_node; return
            q.append(u.left); q.append(u.right)

    # ====== incremental update (ULS / IGT / RUST / RTST) ======
    def partial_fit(self, new_X, new_y, mode="RTST", pi=0.2, mu=5, igt_min_new_per_leaf=10):
        """
        mode: "ULS" | "IGT" | "RUST" | "RTST"  (default: RTST)
          - ULS  : 仅更新叶子统计（不改 split）
          - IGT  : 在叶子上继续生长（有足够样本时）
          - RUST : 只更新选中内部节点的分裂函数并在子树内重路由
          - RTST : 剪成叶子并重训子树
        pi : 选中的内部节点占比（RUST/RTST 用；按 p(n) ∝ (|Tn|+1)^(-1) 抽样）
        mu : 叶子最小样本数（更新后不足则剪枝合并）
        igt_min_new_per_leaf : IGT 时，叶子需要的最小样本量门槛
        """
        # 1) 追加新数据并先路由到当前叶子（ULS 已满足）
        if new_X is not None and len(new_X) > 0:
            new_X = np.asarray(new_X); new_y = np.asarray(new_y, dtype=int)
            if self._X_ref is None:
                self._X_ref, self._y_ref = new_X, new_y
                self._idx_ref = np.arange(len(new_y), dtype=int)
                add_idx = self._idx_ref.copy()
            else:
                start = len(self._idx_ref)
                self._X_ref = np.vstack([self._X_ref, new_X])
                self._y_ref = np.concatenate([self._y_ref, new_y])
                add_idx = np.arange(start, start + len(new_y), dtype=int)
                self._idx_ref = np.concatenate([self._idx_ref, add_idx])
            # 更新类别总数
            self.n_classes_ = int(max(self.n_classes_ or 0, np.max(self._y_ref) + 1))
            # 先按现有树路由新增样本到叶子
            for i in add_idx:
                leaf = self._route_single(self.root, self._X_ref[i])
                if leaf.leaf_indices is None:
                    leaf.leaf_indices = np.array([i], dtype=int)
                else:
                    leaf.leaf_indices = np.concatenate([leaf.leaf_indices, [i]])
                self._recompute_leaf_stats(leaf)

        mode = mode.upper()

        # 2) ULS：只保持叶子统计已更新即可
        if mode == "ULS":
            self._refresh_metric_if_needed()  # <<< 新增
            return self

        # 3) IGT：在满足条件的叶子处继续生长
        if mode == "IGT":
            q = deque([self.root])
            while q:
                u = q.popleft()
                if u is None: continue
                if u.is_leaf:
                    ids = u.leaf_indices if u.leaf_indices is not None else np.array([], dtype=int)
                    if ids.size >= max(2*self.min_samples_leaf, igt_min_new_per_leaf):
                        Xs = self._X_ref[ids]; ys = self._y_ref[ids]
                        if np.unique(ys).size > 1:
                            rebuilt = self._grow_node(Xs, ys, ids, depth=self._depth_of(u))
                            self._replace_node(u, rebuilt)
                else:
                    q.append(u.left); q.append(u.right)
            self._refresh_metric_if_needed()  # <<< 新增
            self.root = self._prune_min_leaf(self.root, mu)
            return self

        # 4) RUST / RTST：先抽样需要更新的内部节点
        to_update = self._sample_update_nodes(pi=pi)
        if not to_update:
            return self

        if mode == "RUST":
            # 仅更新分裂函数
            for node in to_update:
                # 收集子树样本
                ids = []
                qq = deque([node])
                while qq:
                    u = qq.popleft()
                    if u is None: continue
                    if u.is_leaf:
                        if u.leaf_indices is not None: ids.append(u.leaf_indices)
                    else:
                        qq.append(u.left); qq.append(u.right)
                if not ids: continue
                ids = np.concatenate(ids)
                Xs = self._X_ref[ids]; ys = self._y_ref[ids]
                classes_here = np.unique(ys)
                if classes_here.size <= 1 or Xs.shape[0] < 2*self.min_samples_leaf:
                    continue

                # 重算局部质心（用子树样本）
                if classes_here.size > self.max_class_subset:
                    subset = self.rng.choice(classes_here, size=self.max_class_subset, replace=False)
                else:
                    subset = classes_here
                C, L = [], []
                for c in subset:
                    Xc = Xs[ys == c]
                    C.append(Xc.mean(axis=0)); L.append(c)
                C = np.stack(C, axis=0); L = np.array(L)

                # 用信息增益选 e_k
                nn = nearest_centroid_assign(Xs, C, M=self.M_)
                byc = defaultdict(list)
                for i, ci in enumerate(nn): byc[ci].append(i)
                for k in byc.keys(): byc[k] = np.array(byc[k], dtype=int)

                best_gain, best_e, best_L, best_R = -1.0, None, None, None
                for _ in range(self.n_candidate_splits):
                    e = self.rng.integers(0, 2, size=C.shape[0], dtype=int)
                    Ls, Rs = [], []
                    for ci, ee in enumerate(e):
                        loc = byc.get(ci, None)
                        if loc is None or loc.size == 0: continue
                        (Ls if ee == 0 else Rs).append(loc)
                    if not Ls or not Rs: continue
                    L_loc = np.concatenate(Ls); R_loc = np.concatenate(Rs)
                    if L_loc.size < self.min_samples_leaf or R_loc.size < self.min_samples_leaf: continue
                    gain = information_gain(ys, ys[L_loc], ys[R_loc])
                    if gain > best_gain:
                        best_gain, best_e, best_L, best_R = gain, e, L_loc, R_loc
                if best_gain <= 0 or best_L is None:
                    continue

                # 覆盖分裂参数并在子树内重路由
                node.is_leaf = False
                node.centroids = C
                node.centroid_labels = L
                node.e_lr = best_e.astype(int)
                self._route_indices_through_subtree(node.left,  ids[best_L])
                self._route_indices_through_subtree(node.right, ids[best_R])

            self._refresh_metric_if_needed()  # <<< 新增
            self.root = self._prune_min_leaf(self.root, mu)
            return self

        # 5) RTST：剪枝并重训子树（主算法）
        if mode == "RTST":
            for node in to_update:
                # 收集该子树样本
                ids = []
                qq = deque([node])
                while qq:
                    u = qq.popleft()
                    if u is None: continue
                    if u.is_leaf:
                        if u.leaf_indices is not None: ids.append(u.leaf_indices)
                    else:
                        qq.append(u.left); qq.append(u.right)
                if not ids: continue
                ids = np.concatenate(ids)
                # 以该节点当前深度重建子树
                depth = self._depth_of(node)
                rebuilt = self._grow_node(self._X_ref[ids], self._y_ref[ids], ids, depth=depth)
                self._replace_node(node, rebuilt)

            self._refresh_metric_if_needed()  # <<< 新增
            self.root = self._prune_min_leaf(self.root, mu)
            return self

        raise ValueError("mode must be one of {'ULS','IGT','RUST','RTST'}")

    def compress_to_memory(self, X_keep, y_keep):
        """
        用给定的小型内存（旧类exemplars + 本轮新数据）替换内部训练缓存，
        并把所有样本按当前树结构重新路由到叶子（不改split）。
        """
        X_keep = np.asarray(X_keep)
        y_keep = np.asarray(y_keep, dtype=int)

        # 替换全局缓存
        self._X_ref = X_keep
        self._y_ref = y_keep
        self._idx_ref = np.arange(len(y_keep), dtype=int)
        self.n_classes_ = int(np.max(y_keep)) + 1 if len(y_keep) else (self.n_classes_ or 0)

        # 清空所有叶子索引
        for u in self._collect_nodes_bfs():
            if u.is_leaf:
                u.leaf_indices = np.array([], dtype=int)

        # 重新把所有样本路由到当前树的叶子
        for i in range(len(y_keep)):
            leaf = self._route_single(self.root, self._X_ref[i])
            if leaf.leaf_indices is None:
                leaf.leaf_indices = np.array([i], dtype=int)
            else:
                leaf.leaf_indices = np.concatenate([leaf.leaf_indices, [i]])
        # 同步叶子统计
        for u in self._collect_nodes_bfs():
            if u.is_leaf and u.leaf_indices is not None:
                self._recompute_leaf_stats(u)


# ---------- Forest wrapper ----------
class NCMForest:
    def __init__(self,
                 n_estimators=20,
                 max_depth=10,
                 min_samples_leaf=5,
                 max_class_subset=8,
                 n_candidate_splits=32,
                 bootstrap=True,
                 random_state=None,
                 metric="euclidean",   # 新增
                 ridge=1e-3,
                 use_diag=False,
                 update_metric_on_partial=True):
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.min_samples_leaf = min_samples_leaf
        self.max_class_subset = max_class_subset
        self.n_candidate_splits = n_candidate_splits
        self.bootstrap = bootstrap
        self.rng = np.random.default_rng(random_state)
        self.trees = []
        self.n_classes_ = None
        # 存一下给建树用
        self.metric = metric
        self.ridge = ridge
        self.use_diag = use_diag
        self.update_metric_on_partial = update_metric_on_partial


    def fit(self, X, y):
        X = np.asarray(X); y = np.asarray(y, dtype=int)
        self.n_classes_ = int(np.max(y)) + 1
        self.trees = []
        n = X.shape[0]
        for _ in range(self.n_estimators):
            idx = self.rng.integers(0, n, size=n) if self.bootstrap else np.arange(n)
            tree = NCMTree(
                max_depth=self.max_depth,
                min_samples_leaf=self.min_samples_leaf,
                max_class_subset=self.max_class_subset,
                n_candidate_splits=self.n_candidate_splits,
                random_state=int(self.rng.integers(0, 1_000_000)),
                metric=self.metric, ridge=self.ridge, use_diag=self.use_diag,
                update_metric_on_partial=self.update_metric_on_partial
            )
            tree.fit(X[idx], y[idx])
            self.trees.append(tree)
        return self

    def predict_proba(self, X):
        X = np.asarray(X)
        # 关键：固定聚合器列数为“全局类别数”
        agg = np.zeros((len(X), self.n_classes_), dtype=float)
        for t in self.trees:
            # 防御：确保每棵树输出宽度与森林一致
            if t.n_classes_ != self.n_classes_:
                t.n_classes_ = self.n_classes_
            p = t.predict_proba(X)  # shape == (N, self.n_classes_)
            # 若个别实现仍返回更窄的矩阵，这里再做一次兜底 padding
            if p.shape[1] < self.n_classes_:
                pad = np.zeros((p.shape[0], self.n_classes_ - p.shape[1]), dtype=p.dtype)
                p = np.hstack([p, pad])
            agg += p
        return agg / max(1, len(self.trees))

    def predict(self, X):
        return np.argmax(self.predict_proba(X), axis=1)

    def partial_fit(self, new_X, new_y, mode="RTST", pi=0.2, mu=5, igt_min_new_per_leaf=10):
        for t in self.trees:
            t.partial_fit(new_X, new_y, mode=mode, pi=pi, mu=mu, igt_min_new_per_leaf=igt_min_new_per_leaf)
        # 同步全局类别数（增量阶段可能引入新类）
        if new_y is not None and len(new_y) > 0:
            self.n_classes_ = max(self.n_classes_ or 0, int(np.max(new_y)) + 1)
        # 无论是否有新类，都把树的 n_classes_ 与森林对齐，避免预测期再对齐
        for t in self.trees:
            t.n_classes_ = self.n_classes_
        return self

    def compress_to_memory(self, X_keep, y_keep):
        for t in self.trees:
            t.compress_to_memory(X_keep, y_keep)
        if len(y_keep):
            self.n_classes_ = int(np.max(y_keep)) + 1
        # 对齐
        for t in self.trees:
            t.n_classes_ = self.n_classes_

# ---------- Quick demo ----------
# ==== 合成数据生成 ====
rng = np.random.default_rng(3)

def make_blob(center, n=120, std=0.6):
    return center + std * rng.standard_normal((n, 2))

def make_class(c_id, n_tr=120, n_te=60, std=0.6):
    # 让类中心分开一些
    center = rng.uniform(low=-10.0, high=10.0, size=2) + rng.normal(0, 0.5, 2)
    Xc = make_blob(center, n=n_tr + n_te, std=std)
    idx = rng.permutation(Xc.shape[0])
    tr, te = idx[:n_tr], idx[n_tr:]
    Xtr_c, Xte_c = Xc[tr], Xc[te]
    ytr_c = np.full(len(tr), c_id, dtype=int)
    yte_c = np.full(len(te), c_id, dtype=int)
    return Xtr_c, ytr_c, Xte_c, yte_c


if __name__ == "__main__":
    # ==== 配置 ====
    INIT_CLASSES = 3
    TARGET_CLASSES = 15
    STEP_MIN, STEP_MAX = 2, 3          # 每轮新增类数 ∈ [2,3]
    MODE = "RTST"                       # 可选: "ULS"/"IGT"/"RUST"/"RTST"
    PI = 0.3
    MU = 5
    IGT_MIN = 12

    # 距离度量（与你的 NCMForest 改动保持一致）
    METRIC = "mahalanobis"              # "euclidean" 或 "mahalanobis"
    USE_DIAG = True                     # 马氏对角近似更稳
    RIDGE = 1e-3
    BOOTSTRAP = False

    # ==== 生成初始数据并训练初始模型 ====
    Xtr_all, ytr_all, Xte_all, yte_all = [], [], [], []
    c = 0
    for _ in range(INIT_CLASSES):
        Xtr_c, ytr_c, Xte_c, yte_c = make_class(c)
        Xtr_all.append(Xtr_c); ytr_all.append(ytr_c)
        Xte_all.append(Xte_c); yte_all.append(yte_c)
        c += 1

    Xtr0 = np.vstack(Xtr_all); ytr0 = np.concatenate(ytr_all)
    Xte0 = np.vstack(Xte_all); yte0 = np.concatenate(yte_all)

    clf = NCMForest(
        n_estimators=15,
        max_depth=8,
        min_samples_leaf=5,
        max_class_subset=3,
        n_candidate_splits=64,
        bootstrap=BOOTSTRAP,
        metric=METRIC,
        use_diag=USE_DIAG,
        ridge=RIDGE,
        update_metric_on_partial=True
    )
    clf.fit(Xtr0, ytr0)

    # 初始评估
    ypred0 = clf.predict(Xte0)
    acc0 = accuracy_score(yte0, ypred0)
    mf10 = f1_score(yte0, ypred0, average='macro')
    print(f"[Init {INIT_CLASSES} classes] ACC={acc0:.4f}  macroF1={mf10:.4f}")

    # ==== 逐轮增加新类（每次 2~3 个）直到 TARGET_CLASSES ====
    cur_classes = INIT_CLASSES
    round_id = 1
    Xte_seen = Xte0
    yte_seen = yte0

    while cur_classes < TARGET_CLASSES:
        step = int(rng.integers(STEP_MIN, STEP_MAX + 1))
        new_classes = list(range(cur_classes, min(cur_classes + step, TARGET_CLASSES)))

        # 生成这些新类的数据
        Xtr_new_list, ytr_new_list = [], []
        Xte_new_list, yte_new_list = [], []
        for cid in new_classes:
            Xtr_c, ytr_c, Xte_c, yte_c = make_class(cid)
            Xtr_new_list.append(Xtr_c); ytr_new_list.append(ytr_c)
            Xte_new_list.append(Xte_c); yte_new_list.append(yte_c)

        # 本轮所有新类一次性增量
        Xtr_new = np.vstack(Xtr_new_list)
        ytr_new = np.concatenate(ytr_new_list)
        clf.partial_fit(Xtr_new, ytr_new, mode=MODE, pi=PI, mu=MU, igt_min_new_per_leaf=IGT_MIN)

        # 扩展测试集到“所有已见到的类”
        Xte_seen = np.vstack([Xte_seen, np.vstack(Xte_new_list)])
        yte_seen = np.concatenate([yte_seen, np.concatenate(yte_new_list)])

        # 评估
        ypred_seen = clf.predict(Xte_seen)

        # 全部
        acc_all = accuracy_score(yte_seen, ypred_seen)
        mf1_all = f1_score(yte_seen, ypred_seen, average='macro', zero_division=0)

        # 旧类 / 新类标签集合
        old_labels = list(range(cur_classes))  # 本轮前的类
        new_labels = list(range(cur_classes, cur_classes + len(new_classes)))

        # OLD：用 labels=old_labels 在“全体样本上”计 F1；ACC 只在旧类样本上计
        old_mask = np.isin(yte_seen, old_labels)
        acc_old = ((yte_seen == ypred_seen) & old_mask).sum() / max(old_mask.sum(), 1)
        mf1_old = f1_score(yte_seen, ypred_seen, labels=old_labels, average='macro', zero_division=0)

        # NEW：同理
        new_mask = np.isin(yte_seen, new_labels)
        acc_new = ((yte_seen == ypred_seen) & new_mask).sum() / max(new_mask.sum(), 1)
        mf1_new = f1_score(yte_seen, ypred_seen, labels=new_labels, average='macro', zero_division=0)

        print(f"[Round {round_id:02d}] +{len(new_classes)} -> {cur_classes + len(new_classes)} | "
              f"ALL  ACC={acc_all:.4f}  mF1={mf1_all:.4f}  | "
              f"OLD  ACC={acc_old:.4f}  mF1={mf1_old:.4f}  | "
              f"NEW  ACC={acc_new:.4f}  mF1={mf1_new:.4f}")
        cur_classes += len(new_classes)  # <---
        round_id += 1  # <---

    ypred_final = clf.predict(Xte_seen)
    print("\n[Final report | all seen classes]")
    print(classification_report(yte_seen, ypred_final, digits=4))