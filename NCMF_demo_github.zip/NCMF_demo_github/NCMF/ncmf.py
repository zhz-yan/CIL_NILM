# ncm_forest_incremental.py
import numpy as np
from collections import Counter, defaultdict, deque
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.metrics import classification_report

# ---------- Utils ----------
def entropy(y):
    if y.size == 0:
        return 0.0
    counts = np.bincount(y)
    probs = counts[counts > 0].astype(float) / y.size
    return -np.sum(probs * np.log2(probs))

def information_gain(y_parent, y_left, y_right):
    H_parent = entropy(y_parent)
    n = y_parent.size
    n_l = y_left.size
    n_r = y_right.size
    if n_l == 0 or n_r == 0:
        return 0.0
    return H_parent - (n_l / n) * entropy(y_left) - (n_r / n) * entropy(y_right)

def nearest_centroid_assign(X, centroids):
    x2 = np.sum(X * X, axis=1, keepdims=True)           # [N,1]
    c2 = np.sum(centroids * centroids, axis=1)[None, :] # [1,K]
    dist2 = x2 + c2 - 2 * (X @ centroids.T)             # [N,K]
    return np.argmin(dist2, axis=1)

# ---------- NCM Tree ----------
class NCMTreeNode:
    __slots__ = ("is_leaf", "class_counts", "centroids", "centroid_labels", "e_lr",
                 "left", "right",
                 # incremental: store indices of samples reaching this leaf
                 "leaf_indices")

    def __init__(self, is_leaf=False):
        self.is_leaf = is_leaf
        self.class_counts = None
        self.centroids = None
        self.centroid_labels = None
        self.e_lr = None
        self.left = None
        self.right = None
        self.leaf_indices = None  # np.array of sample indices (for incremental)

class NCMTree:
    def __init__(self,
                 max_depth=10,
                 min_samples_leaf=5,
                 max_class_subset=8,
                 n_candidate_splits=32,
                 random_state=None):
        self.max_depth = max_depth
        self.min_samples_leaf = min_samples_leaf
        self.max_class_subset = max_class_subset
        self.n_candidate_splits = n_candidate_splits
        self.rng = np.random.default_rng(random_state)
        self.root = None
        self.n_classes_ = None

        # buffers for incremental
        self._X_ref = None   # reference to training X (for incremental routing)
        self._y_ref = None   # reference to training y
        self._idx_ref = None # 0..N-1

    # ------- core training -------
    def fit(self, X, y):
        X = np.asarray(X)
        y = np.asarray(y, dtype=int)
        self.n_classes_ = int(np.max(y)) + 1

        # references for incremental updates
        self._X_ref = X
        self._y_ref = y
        self._idx_ref = np.arange(X.shape[0])

        self.root = self._grow_node(X, y, self._idx_ref, depth=0)
        return self

    def _grow_node(self, X, y, idx, depth):
        node = NCMTreeNode()
        # stop
        if (depth >= self.max_depth or
            X.shape[0] <= self.min_samples_leaf or
            np.unique(y).size == 1):
            node.is_leaf = True
            node.class_counts = Counter(y.tolist())
            node.leaf_indices = idx.copy()
            return node

        classes_here = np.unique(y)
        if classes_here.size == 1:
            node.is_leaf = True
            node.class_counts = Counter(y.tolist())
            node.leaf_indices = idx.copy()
            return node

        # class subset K^n
        if classes_here.size > self.max_class_subset:
            subset = self.rng.choice(classes_here, size=self.max_class_subset, replace=False)
        else:
            subset = classes_here

        # centroids on current node data
        centroids, centroid_labels = [], []
        for c in subset:
            Xc = X[y == c]
            centroids.append(Xc.mean(axis=0))
            centroid_labels.append(c)
        centroids = np.stack(centroids, axis=0)
        centroid_labels = np.array(centroid_labels)

        # pre-assign nearest centroid for all samples
        nn_idx = nearest_centroid_assign(X, centroids)
        idx_by_centroid = defaultdict(list)
        for i, ci in enumerate(nn_idx):
            idx_by_centroid[ci].append(i)
        for k in idx_by_centroid.keys():
            idx_by_centroid[k] = np.array(idx_by_centroid[k], dtype=int)

        # try candidate e_k splits
        best_gain, best_e, best_L_loc, best_R_loc = -1.0, None, None, None
        for _ in range(self.n_candidate_splits):
            e = self.rng.integers(0, 2, size=centroids.shape[0], dtype=int)
            Ls, Rs = [], []
            for ci, eci in enumerate(e):
                loc = idx_by_centroid.get(ci, None)
                if loc is None or loc.size == 0:
                    continue
                (Ls if eci == 0 else Rs).append(loc)
            if not Ls or not Rs:
                continue
            L_loc = np.concatenate(Ls, axis=0)
            R_loc = np.concatenate(Rs, axis=0)
            if L_loc.size < self.min_samples_leaf or R_loc.size < self.min_samples_leaf:
                continue
            gain = information_gain(y, y[L_loc], y[R_loc])
            if gain > best_gain:
                best_gain, best_e, best_L_loc, best_R_loc = gain, e, L_loc, R_loc

        if best_gain <= 0 or best_L_loc is None:
            node.is_leaf = True
            node.class_counts = Counter(y.tolist())
            node.leaf_indices = idx.copy()
            return node

        node.is_leaf = False
        node.centroids = centroids
        node.centroid_labels = centroid_labels
        node.e_lr = best_e.astype(int)

        node.left  = self._grow_node(X[best_L_loc], y[best_L_loc], idx[best_L_loc], depth+1)
        node.right = self._grow_node(X[best_R_loc], y[best_R_loc], idx[best_R_loc], depth+1)
        return node

    # ------- inference -------
    def _route_single(self, node, x):
        while not node.is_leaf:
            diffs = node.centroids - x[None, :]
            ci = np.argmin(np.sum(diffs * diffs, axis=1))
            node = node.left if node.e_lr[ci] == 0 else node.right
        return node

    def predict_proba(self, X):
        X = np.asarray(X)
        probs = np.zeros((X.shape[0], self.n_classes_), dtype=float)
        for i, x in enumerate(X):
            leaf = self._route_single(self.root, x)
            counts = np.zeros(self.n_classes_, dtype=float)
            for k, v in leaf.class_counts.items():
                counts[int(k)] = v
            s = counts.sum()
            probs[i] = counts / s if s > 0 else 1.0 / self.n_classes_
        return probs

    def predict(self, X):
        return np.argmax(self.predict_proba(X), axis=1)

    # ------- helpers for incremental -------
    def _collect_nodes_bfs(self):
        nodes = []
        q = deque([self.root])
        while q:
            u = q.popleft()
            nodes.append(u)
            if u and not u.is_leaf:
                q.append(u.left); q.append(u.right)
        return nodes

    def _subtree_size(self, node):
        # count nodes in subtree
        cnt = 0
        q = deque([node])
        while q:
            u = q.popleft()
            if u is None: continue
            cnt += 1
            if not u.is_leaf:
                q.append(u.left); q.append(u.right)
        return cnt

    # compute p(n) ∝ (|T_n|+1)^(-1)
    def _sample_update_nodes(self, pi=0.2, rng=None):
        all_nodes = self._collect_nodes_bfs()
        cand = [n for n in all_nodes if not n.is_leaf]
        if not cand:
            return []
        sizes = np.array([self._subtree_size(n) for n in cand], dtype=float)
        weights = 1.0 / (sizes + 1.0)
        probs = weights / weights.sum()
        k = max(1, int(np.ceil(pi * len(cand))))
        rng = self.rng if rng is None else rng
        sel = rng.choice(len(cand), size=k, replace=False, p=probs)
        return [cand[i] for i in sel]

    def _recompute_leaf_stats(self, node):
        # recompute class_counts from leaf_indices
        ys = self._y_ref[node.leaf_indices]
        node.class_counts = Counter(ys.tolist())

    # route a set of indices through a subtree rooted at 'node'
    def _route_indices_through_subtree(self, node, idxs):
        X = self._X_ref[idxs]
        y = self._y_ref[idxs]
        # BFS over subtree, push indices to leaves
        stack = [(node, idxs)]
        while stack:
            u, ids = stack.pop()
            if u.is_leaf:
                u.leaf_indices = ids
                self._recompute_leaf_stats(u)
                continue
            # split ids by current split
            Xs = self._X_ref[ids]
            nn = nearest_centroid_assign(Xs, u.centroids)
            left_mask = np.zeros(len(ids), dtype=bool)
            for ci, e in enumerate(u.e_lr):
                if e == 0:
                    left_mask |= (nn == ci)
            right_mask = ~left_mask
            if np.any(left_mask):
                stack.append((u.left, ids[left_mask]))
            if np.any(right_mask):
                stack.append((u.right, ids[right_mask]))

    # ------- incremental update (RUST/RTST) -------
    def partial_fit(self, new_X, new_y, strategy="RUST", pi=0.2, mu=5):
        """
        new_X/new_y: 新到的数据（可包含新类）
        strategy: "RUST"（更新选中节点的分裂函数）或 "RTST"（剪枝后重长子树）
        pi: 选中待更新节点的比例（按 p(n) ∝ (|Tn|+1)^-1 抽样）
        mu: 叶子最小样本数（更新后如出现<mu的叶子，将在重建中被合并/剪枝）
        """
        # 1) append data references（demo：直接拼接全量；实际可做 reservoir/分配至叶子）
        if new_X is not None and len(new_X) > 0:
            new_X = np.asarray(new_X)
            new_y = np.asarray(new_y, dtype=int)
            # append to reference buffers
            if self._X_ref is None:
                self._X_ref, self._y_ref = new_X, new_y
            else:
                self._X_ref = np.vstack([self._X_ref, new_X])
                self._y_ref = np.concatenate([self._y_ref, new_y])
            start = len(self._idx_ref)
            add_idx = np.arange(start, start + len(new_y))
            self._idx_ref = np.concatenate([self._idx_ref, add_idx])

            # 将新增样本先路由到现有树叶，作为初始分配
            for i in add_idx:
                leaf = self._route_single(self.root, self._X_ref[i])
                if leaf.leaf_indices is None:
                    leaf.leaf_indices = np.array([i], dtype=int)
                else:
                    leaf.leaf_indices = np.concatenate([leaf.leaf_indices, [i]])
                self._recompute_leaf_stats(leaf)
                self.n_classes_ = int(max(self.n_classes_ or 0, np.max(self._y_ref) + 1))

        # 2) 选择需要更新的内部节点
        to_update = self._sample_update_nodes(pi=pi)

        # 3) 对选中节点做 RUST/RTST
        for node in to_update:
            # 收集该子树内所有叶子的样本索引
            idxs_in_subtree = []
            q = deque([node])
            while q:
                u = q.popleft()
                if u is None: continue
                if u.is_leaf:
                    if u.leaf_indices is not None:
                        idxs_in_subtree.append(u.leaf_indices)
                else:
                    q.append(u.left); q.append(u.right)
            if not idxs_in_subtree:
                continue
            idxs_in_subtree = np.concatenate(idxs_in_subtree, axis=0)

            Xs = self._X_ref[idxs_in_subtree]
            ys = self._y_ref[idxs_in_subtree]

            if strategy.upper() == "RUST":
                # —— 仅更新当前节点的分裂函数（breadth-first 外层调用）
                # 与 _grow_node 相同的逻辑，只是局部更新
                classes_here = np.unique(ys)
                # 若无法有效分裂就跳过
                if classes_here.size <= 1 or Xs.shape[0] < 2*self.min_samples_leaf:
                    continue

                if classes_here.size > self.max_class_subset:
                    subset = np.random.default_rng().choice(classes_here, size=self.max_class_subset, replace=False)
                else:
                    subset = classes_here

                centroids, centroid_labels = [], []
                for c in subset:
                    Xc = Xs[ys == c]
                    centroids.append(Xc.mean(axis=0))
                    centroid_labels.append(c)
                centroids = np.stack(centroids, axis=0)
                centroid_labels = np.array(centroid_labels)

                nn_idx = nearest_centroid_assign(Xs, centroids)
                idx_by_centroid = defaultdict(list)
                for i, ci in enumerate(nn_idx):
                    idx_by_centroid[ci].append(i)
                for k in idx_by_centroid.keys():
                    idx_by_centroid[k] = np.array(idx_by_centroid[k], dtype=int)

                best_gain, best_e, best_L_loc, best_R_loc = -1.0, None, None, None
                for _ in range(self.n_candidate_splits):
                    e = np.random.default_rng().integers(0, 2, size=centroids.shape[0], dtype=int)
                    Ls, Rs = [], []
                    for ci, eci in enumerate(e):
                        loc = idx_by_centroid.get(ci, None)
                        if loc is None or loc.size == 0:
                            continue
                        (Ls if eci == 0 else Rs).append(loc)
                    if not Ls or not Rs:
                        continue
                    L_loc = np.concatenate(Ls, axis=0); R_loc = np.concatenate(Rs, axis=0)
                    if L_loc.size < self.min_samples_leaf or R_loc.size < self.min_samples_leaf:
                        continue
                    gain = information_gain(ys, ys[L_loc], ys[R_loc])
                    if gain > best_gain:
                        best_gain, best_e, best_L_loc, best_R_loc = gain, e, L_loc, R_loc
                if best_gain <= 0 or best_L_loc is None:
                    # 无改进则跳过
                    continue

                # 覆盖当前节点参数
                node.is_leaf = False
                node.centroids = centroids
                node.centroid_labels = centroid_labels
                node.e_lr = best_e.astype(int)

                # 子树内重新路由样本（保持原左右子树结构，只更新分配）
                left_ids = idxs_in_subtree[best_L_loc]
                right_ids = idxs_in_subtree[best_R_loc]
                self._route_indices_through_subtree(node.left, left_ids)
                self._route_indices_through_subtree(node.right, right_ids)

            else:  # RTST
                # —— 将该节点剪成叶子，再以其样本为根重建子树
                # 简化实现：以当前深度为根，调用 _grow_node 重建
                depth_queue = [(self.root, 0)]
                target_depth = None
                # 找到 node 的深度
                while depth_queue:
                    u, d = depth_queue.pop()
                    if u is node:
                        target_depth = d; break
                    if u and not u.is_leaf:
                        depth_queue.append((u.left, d+1))
                        depth_queue.append((u.right, d+1))
                # 用同一深度约束重建
                rebuilt = self._grow_node(self._X_ref[idxs_in_subtree],
                                          self._y_ref[idxs_in_subtree],
                                          idxs_in_subtree,
                                          depth=target_depth if target_depth is not None else 0)
                # 将 rebuilt 挂到原父节点（需要一次遍历替换引用）
                q = deque([self.root])
                while q:
                    u = q.popleft()
                    if u is None or u.is_leaf: continue
                    if u.left is node:
                        u.left = rebuilt; break
                    if u.right is node:
                        u.right = rebuilt; break
                    q.append(u.left); q.append(u.right)

        # 4) 最后一次扫过所有叶子，确保 class_counts 同步
        for u in self._collect_nodes_bfs():
            if u.is_leaf and u.leaf_indices is not None:
                self._recompute_leaf_stats(u)

# ---------- Forest wrapper ----------
class NCMForest:
    def __init__(self,
                 n_estimators=20,
                 max_depth=10,
                 min_samples_leaf=5,
                 max_class_subset=8,
                 n_candidate_splits=32,
                 bootstrap=True,
                 random_state=None):
        self.n_estimators = n_estimators
        self.max_depth = max_depth
        self.min_samples_leaf = min_samples_leaf
        self.max_class_subset = max_class_subset
        self.n_candidate_splits = n_candidate_splits
        self.bootstrap = bootstrap
        self.rng = np.random.default_rng(random_state)
        self.trees = []
        self.n_classes_ = None

    def fit(self, X, y):
        X = np.asarray(X); y = np.asarray(y, dtype=int)
        self.n_classes_ = int(np.max(y)) + 1
        self.trees = []
        n = X.shape[0]
        for _ in range(self.n_estimators):
            if self.bootstrap:
                idx = self.rng.integers(0, n, size=n)
            else:
                idx = np.arange(n)
            tree = NCMTree(max_depth=self.max_depth,
                           min_samples_leaf=self.min_samples_leaf,
                           max_class_subset=self.max_class_subset,
                           n_candidate_splits=self.n_candidate_splits,
                           random_state=int(self.rng.integers(0, 1_000_000)))
            tree.fit(X[idx], y[idx])
            self.trees.append(tree)
        return self

    def predict_proba(self, X):
        agg = None
        for t in self.trees:
            p = t.predict_proba(X)
            agg = p if agg is None else agg + p
        return agg / len(self.trees)

    def predict(self, X):
        return np.argmax(self.predict_proba(X), axis=1)

    # 增量：把 new_X/new_y 喂给每棵树的 partial_fit
    def partial_fit(self, new_X, new_y, strategy="RUST", pi=0.2, mu=5):
        for t in self.trees:
            t.partial_fit(new_X, new_y, strategy=strategy, pi=pi, mu=mu)
        # 更新类数（允许新类）
        if new_y is not None and len(new_y) > 0:
            self.n_classes_ = max(self.n_classes_ or 0, int(np.max(new_y)) + 1)
            for t in self.trees:
                t.n_classes_ = self.n_classes_

# ---------- Quick demo ----------
if __name__ == "__main__":
    rng = np.random.default_rng(0)

    def make_blob(center, n=120, std=0.6):
        return center + std * rng.standard_normal((n, 2))

    # 初始三类
    X0 = make_blob(np.array([0.0, 0.0]))
    X1 = make_blob(np.array([3.0, 0.0]))
    X2 = make_blob(np.array([1.5, 2.5]))
    X = np.vstack([X0, X1, X2])
    y = np.array([0]*len(X0) + [1]*len(X1) + [2]*len(X2))

    # 训练/测试
    idx = rng.permutation(X.shape[0])
    tr, te = idx[:300], idx[300:]
    Xtr, ytr = X[tr], y[tr]
    Xte, yte = X[te], y[te]

    clf = NCMForest(n_estimators=15, max_depth=8, min_samples_leaf=5,
                    max_class_subset=3, n_candidate_splits=64, bootstrap=True, random_state=42)
    clf.fit(Xtr, ytr)

    # ---- baseline ----
    ypred = clf.predict(Xte)
    print("[Before incremental]")
    print(classification_report(yte, ypred, digits=4))   # per-class metrics
    print("Confusion matrix:\n", confusion_matrix(yte, ypred))

    # 新类到来（类3）
    X3 = make_blob(np.array([3.2, 2.8]), n=80, std=0.55)
    y3 = np.full(len(X3), 3, dtype=int)

    # 增量更新
    clf.partial_fit(X3, y3, strategy="RUST", pi=0.2, mu=5)

    # ---- after incremental ----
    Xte2 = np.vstack([Xte, X3])
    yte2 = np.concatenate([yte, y3])
    ypred2 = clf.predict(Xte2)

    print("\n[After incremental (RUST)]")
    print(classification_report(yte2, ypred2, digits=4))
    print("Confusion matrix:\n", confusion_matrix(yte2, ypred2))