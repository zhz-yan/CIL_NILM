import numpy as np
from collections import defaultdict


def herding_select(Xc, m):
    """
    从类 c 的样本 Xc (nc, d) 中选 m 个 exemplar，使其均值逼近整体均值（iCaRL 经典做法）。
    """
    if len(Xc) <= m:
        return Xc
    mu = Xc.mean(axis=0, keepdims=True)                   # 类均值
    selected = []
    running = np.zeros_like(mu)
    idx_all = np.arange(len(Xc))
    used = np.zeros(len(Xc), dtype=bool)
    for _ in range(m):
        # 选使 (running + x)/(|S|+1) 最接近 mu 的样本
        residual = mu * (len(selected) + 1) - (running + Xc)
        i = np.argmin(np.linalg.norm(residual, axis=1) + used * 1e9)
        used[i] = True
        selected.append(Xc[i])
        running += Xc[i]
    return np.stack(selected, axis=0)

class ExemplarMemory:
    def __init__(self, budget=None, per_class=None, strategy="herding"):
        """
        budget:  整体容量上限（优先级低于 per_class）
        per_class: 每类最多保留的样本数（若给定则忽略 budget）
        strategy: "herding" | "random"
        """
        assert budget is not None or per_class is not None, "需要设置 budget 或 per_class。"
        self.budget = budget
        self.per_class = per_class
        self.strategy = strategy
        self.store = defaultdict(lambda: np.empty((0,0)))   # cid -> (k,d)

    def _quota(self, n_classes):
        if self.per_class is not None:
            return self.per_class
        return max(1, self.budget // max(1, n_classes))

    def _select(self, Xc, m):
        if self.strategy == "herding":
            return herding_select(Xc, m)
        # random
        idx = np.random.permutation(len(Xc))[:m]
        return Xc[idx]

    def add_from(self, X, y):
        """
        将 (X,y) 中每个类的样本加入内存，并按配额重采样。
        """
        if len(X) == 0:
            return
        classes = np.unique(y)
        # 先合并，再统一重采样到配额
        for c in classes:
            Xc = X[y == c]
            if self.store[c].size == 0:
                self.store[c] = Xc.copy()
            else:
                self.store[c] = np.vstack([self.store[c], Xc])

        # 统一裁剪
        all_classes = list(self.store.keys())
        q = self._quota(len(all_classes))
        for c in all_classes:
            Xc = self.store[c]
            # 初始化时 d 未知，用当前 Xc 的维度替代
            if Xc.ndim == 1: Xc = Xc[None, :]
            if len(Xc) > q:
                self.store[c] = self._select(Xc, q)
            else:
                self.store[c] = Xc

        # 若用总预算，再做一次全局裁剪（均匀降低每类配额）
        if self.per_class is None and self.budget is not None:
            while sum(len(v) for v in self.store.values()) > self.budget:
                # 每类减 1（先从样本数最多的类开始）
                cmax = max(self.store.keys(), key=lambda c: len(self.store[c]))
                self.store[cmax] = self.store[cmax][:-1]

    def sample_all(self):
        """
        返回 (X_mem, y_mem)。若为空，给 (0, d) 的空阵。
        """
        if len(self.store) == 0:
            return np.empty((0,0)), np.array([], dtype=int)
        Xs, ys = [], []
        for c, Xc in self.store.items():
            if len(Xc) == 0: continue
            Xs.append(Xc)
            ys.append(np.full(len(Xc), int(c), dtype=int))
        Xs = np.vstack(Xs) if Xs else np.empty((0,0))
        ys = np.concatenate(ys) if ys else np.array([], dtype=int)
        return Xs, ys

    def __len__(self):
        return sum(len(v) for v in self.store.values())