# ncm_forest_incremental.py
import numpy as np
from collections import Counter, defaultdict, deque
from sklearn.metrics import classification_report, confusion_matrix
from ncmf_2 import NCMTreeNode, NCMTree, NCMForest
from exemplar_memory import ExemplarMemory

# ---------- Quick demo ----------
if __name__ == "__main__":
    from sklearn.metrics import accuracy_score, f1_score, classification_report
    rng = np.random.default_rng(0)

    # ----- 数据生成 -----
    def make_blob(center, n=120, std=0.6):
        return center + std * rng.standard_normal((n, 2))

    def make_class(c_id, n_tr=120, n_te=60, std=0.6):
        center = rng.uniform(-10, 10, size=2) + rng.normal(0, 0.5, 2)
        Xc = make_blob(center, n=n_tr+n_te, std=std)
        idx = rng.permutation(len(Xc))
        tr, te = idx[:n_tr], idx[n_tr:]
        return Xc[tr], np.full(n_tr, c_id, int), Xc[te], np.full(len(Xc)-n_tr, c_id, int)

    # ----- 配置 -----
    INIT_CLASSES = 5
    TARGET_CLASSES = 50
    STEP_MIN, STEP_MAX = 3, 5
    MODE = "IGT"       # 可改为 "ULS" / "IGT" / "RUST" / "RTST"
    PI = 0.25
    MU = 5
    IGT_MIN = 12

    # exemplar 设置：二选一
    mem = ExemplarMemory(budget_per_class=10, strategy="herding", random_state=0)
    # mem = ExemplarMemory(total_budget=2000, strategy="herding", random_state=0)  # 示例：总预算 2000

    # ----- 初始训练 -----
    Xtr_all, ytr_all, Xte_all, yte_all = [], [], [], []
    c = 0
    for _ in range(INIT_CLASSES):
        Xtr_c, ytr_c, Xte_c, yte_c = make_class(c)
        Xtr_all.append(Xtr_c); ytr_all.append(ytr_c)
        Xte_all.append(Xte_c); yte_all.append(yte_c)
        c += 1
    Xtr0 = np.vstack(Xtr_all); ytr0 = np.concatenate(ytr_all)
    Xte_seen = np.vstack(Xte_all); yte_seen = np.concatenate(yte_all)

    clf = NCMForest(n_estimators=50, max_depth=20, min_samples_leaf=3,
                    max_class_subset=8, n_candidate_splits=64,
                    bootstrap=True)
    clf.fit(Xtr0, ytr0)

    # 初始 exemplar（基于初始训练集）
    mem.build_from_dataset(Xtr0, ytr0)

    ypred0 = clf.predict(Xte_seen)
    print(f"[Init {INIT_CLASSES}] ACC={accuracy_score(yte_seen, ypred0):.4f} "
          f"macroF1={f1_score(yte_seen, ypred0, average='macro'):.4f}")

    # ----- 逐轮增类 -----
    cur_classes = INIT_CLASSES
    round_id = 1
    while cur_classes < TARGET_CLASSES:
        step = int(rng.integers(STEP_MIN, STEP_MAX + 1))
        new_classes = list(range(cur_classes, min(cur_classes + step, TARGET_CLASSES)))

        # 生成本轮新类的数据
        Xtr_new_list, ytr_new_list, Xte_new_list, yte_new_list = [], [], [], []
        for cid in new_classes:
            Xtr_c, ytr_c, Xte_c, yte_c = make_class(cid)
            Xtr_new_list.append(Xtr_c);
            ytr_new_list.append(ytr_c)
            Xte_new_list.append(Xte_c);
            yte_new_list.append(yte_c)

        Xtr_new = np.vstack(Xtr_new_list)
        ytr_new = np.concatenate(ytr_new_list)

        # 取出旧类 exemplars，并与新类训练数据拼接 → 作为本轮增量训练的输入
        Xex, yex = mem.get_all()  # 若还没有 memory，会返回空
        Xinc = np.vstack([Xtr_new, Xex]) if Xex.size else Xtr_new
        yinc = np.concatenate([ytr_new, yex]) if yex.size else ytr_new

        # 增量训练（关键：不再调用 compress_to_memory）
        clf.partial_fit(Xinc, yinc, mode=MODE, pi=PI, mu=MU, igt_min_new_per_leaf=IGT_MIN)

        # 用新类数据更新 memory（total_budget 模式会自动均分）
        mem.update_with_new_classes(Xtr_new, ytr_new,
                                    known_classes_after_update=cur_classes + len(new_classes))

        # 扩展测试集到“所有已见到的类”
        Xte_seen = np.vstack([Xte_seen, *Xte_new_list])
        yte_seen = np.concatenate([yte_seen, *yte_new_list])

        # 评估
        ypred = clf.predict(Xte_seen)
        acc = accuracy_score(yte_seen, ypred)
        mf1 = f1_score(yte_seen, ypred, average='macro')
        print(f"[Round {round_id:02d}] +{len(new_classes)} -> {cur_classes + len(new_classes)} classes | "
              f"{MODE}+ExMem  ACC={acc:.4f}  macroF1={mf1:.4f}")

        cur_classes += len(new_classes)
        round_id += 1

    # 最终报告
    print("\n[Final report]")
    print(classification_report(yte_seen, ypred, digits=4))