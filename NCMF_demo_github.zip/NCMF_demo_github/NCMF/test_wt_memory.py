# ncm_forest_incremental.py
import numpy as np
from collections import Counter, defaultdict, deque
from sklearn.metrics import classification_report, confusion_matrix
from ncmf_2 import NCMTreeNode, NCMTree, NCMForest
# ---------- Utils ----------
def entropy(y):
    if y.size == 0:
        return 0.0
    counts = np.bincount(y)
    probs = counts[counts > 0].astype(float) / y.size
    return -np.sum(probs * np.log2(probs))

def information_gain(y_parent, y_left, y_right):
    H_parent = entropy(y_parent)
    n = y_parent.size
    n_l = y_left.size
    n_r = y_right.size
    if n_l == 0 or n_r == 0:
        return 0.0
    return H_parent - (n_l / n) * entropy(y_left) - (n_r / n) * entropy(y_right)

def nearest_centroid_assign(X, centroids):
    x2 = np.sum(X * X, axis=1, keepdims=True)           # [N,1]
    c2 = np.sum(centroids * centroids, axis=1)[None, :] # [1,K]
    dist2 = x2 + c2 - 2 * (X @ centroids.T)             # [N,K]
    return np.argmin(dist2, axis=1)


# ---------- Quick demo ----------
if __name__ == "__main__":
    from sklearn.metrics import classification_report, accuracy_score, f1_score
    rng = np.random.default_rng(0)

    # ------- 数据生成 -------
    def make_blob(center, n=120, std=0.6):
        return center + std * rng.standard_normal((n, 2))

    def make_class(c_id, n_tr=120, n_te=60, std=0.6):
        # 随机采样一个类中心（让类彼此分开一些）
        center = rng.uniform(low=-10.0, high=10.0, size=2) + rng.normal(0, 0.5, 2)
        Xc = make_blob(center, n=n_tr+n_te, std=std)
        idx = rng.permutation(Xc.shape[0])
        tr, te = idx[:n_tr], idx[n_tr:]
        Xtr_c, Xte_c = Xc[tr], Xc[te]
        ytr_c = np.full(len(tr), c_id, dtype=int)
        yte_c = np.full(len(te), c_id, dtype=int)
        return Xtr_c, ytr_c, Xte_c, yte_c

    # ------- 配置 -------
    INIT_CLASSES = 5
    TARGET_CLASSES = 50
    STEP_MIN, STEP_MAX = 3, 5          # 每轮新增类数的区间（含）
    MODE = "RTST"                      # 可改： "ULS" / "IGT" / "RUST" / "RTST"
    PI = 0.25                          # 选中更新的内部节点占比（RUST/RTST）
    MU = 5                             # 叶子最小样本数
    IGT_MIN = 12                       # IGT 时叶子最小样本阈值

    # ------- 生成初始数据并训练初始模型 -------
    Xtr_all, ytr_all, Xte_all, yte_all = [], [], [], []

    c = 0
    for _ in range(INIT_CLASSES):
        Xtr_c, ytr_c, Xte_c, yte_c = make_class(c)
        Xtr_all.append(Xtr_c); ytr_all.append(ytr_c)
        Xte_all.append(Xte_c); yte_all.append(yte_c)
        c += 1

    Xtr0 = np.vstack(Xtr_all); ytr0 = np.concatenate(ytr_all)
    Xte0 = np.vstack(Xte_all); yte0 = np.concatenate(yte_all)

    clf = NCMForest(
        n_estimators=10,
        max_depth=11,
        min_samples_leaf=2,
        max_class_subset=8,
        n_candidate_splits=64,
        bootstrap=True,
        random_state=42
    )
    clf.fit(Xtr0, ytr0)

    ypred0 = clf.predict(Xte0)
    print(f"[Init {INIT_CLASSES} classes] "
          f"ACC={accuracy_score(yte0, ypred0):.4f}  "
          f"macroF1={f1_score(yte0, ypred0, average='macro'):.4f}")

    # ------- 逐轮增加新类直到 TARGET_CLASSES -------
    cur_classes = INIT_CLASSES
    round_id = 1
    while cur_classes < TARGET_CLASSES:
        step = int(rng.integers(STEP_MIN, STEP_MAX + 1))
        new_classes = list(range(cur_classes, min(cur_classes + step, TARGET_CLASSES)))

        # 生成这些新类的数据
        Xtr_new_list, ytr_new_list = [], []
        Xte_new_list, yte_new_list = [], []
        for cid in new_classes:
            Xtr_c, ytr_c, Xte_c, yte_c = make_class(cid)
            Xtr_new_list.append(Xtr_c); ytr_new_list.append(ytr_c)
            Xte_new_list.append(Xte_c); yte_new_list.append(yte_c)

        # 增量训练（把本轮所有新类一次性喂进去）
        Xtr_new = np.vstack(Xtr_new_list)
        ytr_new = np.concatenate(ytr_new_list)
        clf.partial_fit(Xtr_new, ytr_new, mode=MODE, pi=PI, mu=MU, igt_min_new_per_leaf=IGT_MIN)

        # 扩展测试集为“所有已见到的类”
        Xte_all.append(np.vstack(Xte_new_list))
        yte_all.append(np.concatenate(yte_new_list))
        Xte_seen = np.vstack(Xte_all)
        yte_seen = np.concatenate(yte_all)

        ypred_seen = clf.predict(Xte_seen)
        acc = accuracy_score(yte_seen, ypred_seen)
        mf1 = f1_score(yte_seen, ypred_seen, average='macro')
        print(f"[Round {round_id:02d}] +{len(new_classes)} classes -> {cur_classes + len(new_classes)} total | "
              f"{MODE}  ACC={acc:.4f}  macroF1={mf1:.4f}")

        cur_classes += len(new_classes)
        round_id += 1

    # ------- 最终详细报告（可选） -------
    print("\n[Final report]")
    print(classification_report(yte_seen, ypred_seen, digits=4))